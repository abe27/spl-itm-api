--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg22.10+1)
-- Dumped by pg_dump version 15.1 (Ubuntu 15.1-1.pgdg22.10+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE erpdb;
--
-- Name: erpdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE erpdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE erpdb OWNER TO postgres;

\connect erpdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbt_administrators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_administrators (
    id character varying(21) NOT NULL,
    user_id character varying(21),
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_administrators OWNER TO postgres;

--
-- Name: tbt_areas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_areas (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_areas OWNER TO postgres;

--
-- Name: tbt_departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_departments (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_departments OWNER TO postgres;

--
-- Name: tbt_download_mail_boxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_download_mail_boxes (
    id character varying(21) NOT NULL,
    mail_box_id character varying(21),
    mail_type_id character varying(21),
    batch_no character varying(50) NOT NULL,
    size numeric,
    batch_id text NOT NULL,
    creation_date date,
    creation_time timestamp with time zone,
    flags character varying(10),
    format character varying(5),
    originator character varying(25),
    file_path text,
    is_download boolean,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_download_mail_boxes OWNER TO postgres;

--
-- Name: tbt_factories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_factories (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    inv_prefix character varying(10),
    label_prefix character varying(10),
    value bigint,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_factories OWNER TO postgres;

--
-- Name: tbt_item_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_item_types (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_item_types OWNER TO postgres;

--
-- Name: tbt_jwt_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_jwt_tokens (
    id character varying(60) NOT NULL,
    user_id character varying(21) NOT NULL,
    token text NOT NULL,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_jwt_tokens OWNER TO postgres;

--
-- Name: tbt_mail_boxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_mail_boxes (
    id character varying(21) NOT NULL,
    area_id character varying(21),
    mail_id character varying(50),
    password character varying(50),
    url text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_mail_boxes OWNER TO postgres;

--
-- Name: tbt_mail_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_mail_types (
    id character varying(21) NOT NULL,
    factory_id character varying(21),
    prefix character varying(50) NOT NULL,
    title character varying(50) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_mail_types OWNER TO postgres;

--
-- Name: tbt_positions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_positions (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_positions OWNER TO postgres;

--
-- Name: tbt_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_sections (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_sections OWNER TO postgres;

--
-- Name: tbt_shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_shipments (
    id character varying(21) NOT NULL,
    prefix character varying(10),
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_shipments OWNER TO postgres;

--
-- Name: tbt_system_loggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_system_loggers (
    id character varying(21) NOT NULL,
    user_id character varying(21),
    title character varying(25),
    description text,
    is_success boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_system_loggers OWNER TO postgres;

--
-- Name: tbt_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_units (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_units OWNER TO postgres;

--
-- Name: tbt_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_users (
    id character varying(21) NOT NULL,
    username character varying(10) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(50) NOT NULL,
    password character varying(60) NOT NULL,
    area_id character varying(21),
    whs_id character varying(21),
    factory_id character varying(21),
    position_id character varying(21),
    section_id character varying(21),
    department_id character varying(21),
    avatar_url text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_users OWNER TO postgres;

--
-- Name: tbt_whs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_whs (
    id character varying(21) NOT NULL,
    prefix character varying(10) NOT NULL,
    title character varying(25) NOT NULL,
    value character varying(5),
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_whs OWNER TO postgres;

--
-- Data for Name: tbt_administrators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_administrators (id, user_id, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_administrators (id, user_id, is_active, created_at, updated_at) FROM '$$PATH$$/3527.dat';

--
-- Data for Name: tbt_areas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_areas (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_areas (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3523.dat';

--
-- Data for Name: tbt_departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_departments (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_departments (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3522.dat';

--
-- Data for Name: tbt_download_mail_boxes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_download_mail_boxes (id, mail_box_id, mail_type_id, batch_no, size, batch_id, creation_date, creation_time, flags, format, originator, file_path, is_download, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_download_mail_boxes (id, mail_box_id, mail_type_id, batch_no, size, batch_id, creation_date, creation_time, flags, format, originator, file_path, is_download, is_active, created_at, updated_at) FROM '$$PATH$$/3533.dat';

--
-- Data for Name: tbt_factories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_factories (id, title, description, inv_prefix, label_prefix, value, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_factories (id, title, description, inv_prefix, label_prefix, value, is_active, created_at, updated_at) FROM '$$PATH$$/3534.dat';

--
-- Data for Name: tbt_item_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_item_types (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_item_types (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3530.dat';

--
-- Data for Name: tbt_jwt_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_jwt_tokens (id, user_id, token, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_jwt_tokens (id, user_id, token, is_active, created_at, updated_at) FROM '$$PATH$$/3526.dat';

--
-- Data for Name: tbt_mail_boxes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_mail_boxes (id, area_id, mail_id, password, url, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_mail_boxes (id, area_id, mail_id, password, url, is_active, created_at, updated_at) FROM '$$PATH$$/3532.dat';

--
-- Data for Name: tbt_mail_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_mail_types (id, factory_id, prefix, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_mail_types (id, factory_id, prefix, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3535.dat';

--
-- Data for Name: tbt_positions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_positions (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_positions (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3520.dat';

--
-- Data for Name: tbt_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_sections (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_sections (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3521.dat';

--
-- Data for Name: tbt_shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_shipments (id, prefix, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_shipments (id, prefix, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3531.dat';

--
-- Data for Name: tbt_system_loggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_system_loggers (id, user_id, title, description, is_success, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_system_loggers (id, user_id, title, description, is_success, created_at, updated_at) FROM '$$PATH$$/3529.dat';

--
-- Data for Name: tbt_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_units (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_units (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3528.dat';

--
-- Data for Name: tbt_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_users (id, username, first_name, last_name, email, password, area_id, whs_id, factory_id, position_id, section_id, department_id, avatar_url, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_users (id, username, first_name, last_name, email, password, area_id, whs_id, factory_id, position_id, section_id, department_id, avatar_url, is_active, created_at, updated_at) FROM '$$PATH$$/3525.dat';

--
-- Data for Name: tbt_whs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_whs (id, prefix, title, value, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_whs (id, prefix, title, value, description, is_active, created_at, updated_at) FROM '$$PATH$$/3524.dat';

--
-- Name: tbt_administrators tbt_administrators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_administrators
    ADD CONSTRAINT tbt_administrators_pkey PRIMARY KEY (id);


--
-- Name: tbt_administrators tbt_administrators_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_administrators
    ADD CONSTRAINT tbt_administrators_user_id_key UNIQUE (user_id);


--
-- Name: tbt_areas tbt_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_areas
    ADD CONSTRAINT tbt_areas_pkey PRIMARY KEY (id);


--
-- Name: tbt_areas tbt_areas_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_areas
    ADD CONSTRAINT tbt_areas_title_key UNIQUE (title);


--
-- Name: tbt_departments tbt_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_departments
    ADD CONSTRAINT tbt_departments_pkey PRIMARY KEY (id);


--
-- Name: tbt_departments tbt_departments_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_departments
    ADD CONSTRAINT tbt_departments_title_key UNIQUE (title);


--
-- Name: tbt_download_mail_boxes tbt_download_mail_boxes_batch_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT tbt_download_mail_boxes_batch_no_key UNIQUE (batch_no);


--
-- Name: tbt_download_mail_boxes tbt_download_mail_boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT tbt_download_mail_boxes_pkey PRIMARY KEY (id);


--
-- Name: tbt_factories tbt_factories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_factories
    ADD CONSTRAINT tbt_factories_pkey PRIMARY KEY (id);


--
-- Name: tbt_factories tbt_factories_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_factories
    ADD CONSTRAINT tbt_factories_title_key UNIQUE (title);


--
-- Name: tbt_item_types tbt_item_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_item_types
    ADD CONSTRAINT tbt_item_types_pkey PRIMARY KEY (id);


--
-- Name: tbt_item_types tbt_item_types_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_item_types
    ADD CONSTRAINT tbt_item_types_title_key UNIQUE (title);


--
-- Name: tbt_jwt_tokens tbt_jwt_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT tbt_jwt_tokens_pkey PRIMARY KEY (id);


--
-- Name: tbt_jwt_tokens tbt_jwt_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT tbt_jwt_tokens_token_key UNIQUE (token);


--
-- Name: tbt_jwt_tokens tbt_jwt_tokens_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT tbt_jwt_tokens_user_id_key UNIQUE (user_id);


--
-- Name: tbt_mail_boxes tbt_mail_boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_boxes
    ADD CONSTRAINT tbt_mail_boxes_pkey PRIMARY KEY (id);


--
-- Name: tbt_mail_types tbt_mail_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_types
    ADD CONSTRAINT tbt_mail_types_pkey PRIMARY KEY (id);


--
-- Name: tbt_mail_types tbt_mail_types_prefix_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_types
    ADD CONSTRAINT tbt_mail_types_prefix_key UNIQUE (prefix);


--
-- Name: tbt_positions tbt_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_positions
    ADD CONSTRAINT tbt_positions_pkey PRIMARY KEY (id);


--
-- Name: tbt_positions tbt_positions_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_positions
    ADD CONSTRAINT tbt_positions_title_key UNIQUE (title);


--
-- Name: tbt_sections tbt_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sections
    ADD CONSTRAINT tbt_sections_pkey PRIMARY KEY (id);


--
-- Name: tbt_sections tbt_sections_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sections
    ADD CONSTRAINT tbt_sections_title_key UNIQUE (title);


--
-- Name: tbt_shipments tbt_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_shipments
    ADD CONSTRAINT tbt_shipments_pkey PRIMARY KEY (id);


--
-- Name: tbt_shipments tbt_shipments_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_shipments
    ADD CONSTRAINT tbt_shipments_title_key UNIQUE (title);


--
-- Name: tbt_system_loggers tbt_system_loggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_system_loggers
    ADD CONSTRAINT tbt_system_loggers_pkey PRIMARY KEY (id);


--
-- Name: tbt_units tbt_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_units
    ADD CONSTRAINT tbt_units_pkey PRIMARY KEY (id);


--
-- Name: tbt_units tbt_units_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_units
    ADD CONSTRAINT tbt_units_title_key UNIQUE (title);


--
-- Name: tbt_users tbt_users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT tbt_users_email_key UNIQUE (email);


--
-- Name: tbt_users tbt_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT tbt_users_pkey PRIMARY KEY (id);


--
-- Name: tbt_users tbt_users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT tbt_users_username_key UNIQUE (username);


--
-- Name: tbt_whs tbt_whs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_whs
    ADD CONSTRAINT tbt_whs_pkey PRIMARY KEY (id);


--
-- Name: tbt_whs tbt_whs_prefix_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_whs
    ADD CONSTRAINT tbt_whs_prefix_key UNIQUE (prefix);


--
-- Name: tbt_whs tbt_whs_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_whs
    ADD CONSTRAINT tbt_whs_title_key UNIQUE (title);


--
-- Name: idx_tbt_areas_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_areas_title ON public.tbt_areas USING btree (title);


--
-- Name: idx_tbt_departments_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_departments_title ON public.tbt_departments USING btree (title);


--
-- Name: idx_tbt_factories_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_factories_title ON public.tbt_factories USING btree (title);


--
-- Name: idx_tbt_item_types_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_item_types_title ON public.tbt_item_types USING btree (title);


--
-- Name: idx_tbt_mail_types_prefix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_mail_types_prefix ON public.tbt_mail_types USING btree (prefix);


--
-- Name: idx_tbt_mail_types_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_mail_types_title ON public.tbt_mail_types USING btree (title);


--
-- Name: idx_tbt_positions_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_positions_title ON public.tbt_positions USING btree (title);


--
-- Name: idx_tbt_sections_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_sections_title ON public.tbt_sections USING btree (title);


--
-- Name: idx_tbt_shipments_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_shipments_title ON public.tbt_shipments USING btree (title);


--
-- Name: idx_tbt_units_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_units_title ON public.tbt_units USING btree (title);


--
-- Name: idx_tbt_users_user_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_users_user_name ON public.tbt_users USING btree (username);


--
-- Name: idx_tbt_whs_prefix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_whs_prefix ON public.tbt_whs USING btree (prefix);


--
-- Name: idx_tbt_whs_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_whs_title ON public.tbt_whs USING btree (title);


--
-- Name: tbt_administrators fk_tbt_administrators_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_administrators
    ADD CONSTRAINT fk_tbt_administrators_user FOREIGN KEY (user_id) REFERENCES public.tbt_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_download_mail_boxes fk_tbt_download_mail_boxes_mail_box; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT fk_tbt_download_mail_boxes_mail_box FOREIGN KEY (mail_box_id) REFERENCES public.tbt_mail_boxes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_download_mail_boxes fk_tbt_download_mail_boxes_mail_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT fk_tbt_download_mail_boxes_mail_type FOREIGN KEY (mail_type_id) REFERENCES public.tbt_mail_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_jwt_tokens fk_tbt_jwt_tokens_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT fk_tbt_jwt_tokens_user FOREIGN KEY (user_id) REFERENCES public.tbt_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_mail_boxes fk_tbt_mail_boxes_area; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_boxes
    ADD CONSTRAINT fk_tbt_mail_boxes_area FOREIGN KEY (area_id) REFERENCES public.tbt_areas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_mail_types fk_tbt_mail_types_factory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_types
    ADD CONSTRAINT fk_tbt_mail_types_factory FOREIGN KEY (factory_id) REFERENCES public.tbt_factories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_system_loggers fk_tbt_system_loggers_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_system_loggers
    ADD CONSTRAINT fk_tbt_system_loggers_user FOREIGN KEY (user_id) REFERENCES public.tbt_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_area; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_area FOREIGN KEY (area_id) REFERENCES public.tbt_areas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_department FOREIGN KEY (department_id) REFERENCES public.tbt_departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_factory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_factory FOREIGN KEY (factory_id) REFERENCES public.tbt_factories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_position; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_position FOREIGN KEY (position_id) REFERENCES public.tbt_positions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_section; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_section FOREIGN KEY (section_id) REFERENCES public.tbt_sections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_whs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_whs FOREIGN KEY (whs_id) REFERENCES public.tbt_whs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

