--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg22.10+1)
-- Dumped by pg_dump version 15.1 (Ubuntu 15.1-1.pgdg22.10+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE erpdb;
--
-- Name: erpdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE erpdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE erpdb OWNER TO postgres;

\connect erpdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbt_administrators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_administrators (
    id character varying(21) NOT NULL,
    user_id character varying(21),
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_administrators OWNER TO postgres;

--
-- Name: tbt_affcodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_affcodes (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_affcodes OWNER TO postgres;

--
-- Name: tbt_areas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_areas (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_areas OWNER TO postgres;

--
-- Name: tbt_carton_histories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_carton_histories (
    id character varying(21) NOT NULL,
    carton_id character varying(21),
    pallet_no character varying(15),
    shelve_id character varying(15),
    qty numeric,
    ip_address inet,
    emp_id character varying(10),
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_carton_histories OWNER TO postgres;

--
-- Name: tbt_carton_not_receives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_carton_not_receives (
    id character varying(21) NOT NULL,
    receive_detail_id character varying(21) NOT NULL,
    transfer_out_no character varying(25) NOT NULL,
    part_no text NOT NULL,
    lot_no character varying(8) NOT NULL,
    serial_no character varying(10) NOT NULL,
    qty bigint,
    is_received boolean,
    is_sync boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_carton_not_receives OWNER TO postgres;

--
-- Name: tbt_cartons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_cartons (
    id character varying(21) NOT NULL,
    ledger_id character varying(21) NOT NULL,
    receive_detail_id character varying(21),
    serial_no character varying(15) NOT NULL,
    lot_no character varying(15) NOT NULL,
    line_no character varying(15),
    revise_no character varying(15),
    pallet_no character varying(15),
    shelve_id character varying(21) NOT NULL,
    qty numeric,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_cartons OWNER TO postgres;

--
-- Name: tbt_colors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_colors (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_colors OWNER TO postgres;

--
-- Name: tbt_commercials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_commercials (
    id character varying(21) NOT NULL,
    title character varying(5) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_commercials OWNER TO postgres;

--
-- Name: tbt_customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_customers (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_customers OWNER TO postgres;

--
-- Name: tbt_departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_departments (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_departments OWNER TO postgres;

--
-- Name: tbt_download_mail_boxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_download_mail_boxes (
    id character varying(21) NOT NULL,
    mail_box_id character varying(21),
    mail_type_id character varying(21),
    batch_no character varying(50) NOT NULL,
    size numeric,
    batch_id text NOT NULL,
    creation_date timestamp with time zone,
    flags character varying(10),
    format character varying(5),
    originator character varying(25),
    file_path text,
    is_download boolean,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_download_mail_boxes OWNER TO postgres;

--
-- Name: tbt_factories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_factories (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    inv_prefix character varying(10),
    label_prefix character varying(10),
    value bigint,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_factories OWNER TO postgres;

--
-- Name: tbt_item_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_item_types (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_item_types OWNER TO postgres;

--
-- Name: tbt_jwt_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_jwt_tokens (
    id character varying(60) NOT NULL,
    user_id character varying(21) NOT NULL,
    token text NOT NULL,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_jwt_tokens OWNER TO postgres;

--
-- Name: tbt_kinds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_kinds (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_kinds OWNER TO postgres;

--
-- Name: tbt_last_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_last_invoices (
    id character varying(21) NOT NULL,
    factory_id character varying(21) NOT NULL,
    affcode_id character varying(21) NOT NULL,
    on_year bigint NOT NULL,
    last_running bigint,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_last_invoices OWNER TO postgres;

--
-- Name: tbt_ledgers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_ledgers (
    id character varying(21) NOT NULL,
    area_id character varying(21) NOT NULL,
    whs_id character varying(21) NOT NULL,
    factory_id character varying(21) NOT NULL,
    part_id character varying(21) NOT NULL,
    kind_id character varying(21),
    size_id character varying(21),
    color_id character varying(21),
    item_type_id character varying(21) NOT NULL,
    unit_id character varying(21) NOT NULL,
    dim_width numeric,
    dim_length numeric,
    dim_height numeric,
    gross_weight numeric,
    net_weight numeric,
    qty numeric,
    ctn numeric,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_ledgers OWNER TO postgres;

--
-- Name: tbt_mail_boxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_mail_boxes (
    id character varying(21) NOT NULL,
    area_id character varying(21),
    mail_id character varying(50),
    password character varying(50),
    url text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_mail_boxes OWNER TO postgres;

--
-- Name: tbt_mail_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_mail_types (
    id character varying(21) NOT NULL,
    factory_id character varying(21),
    prefix character varying(50) NOT NULL,
    title character varying(50) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_mail_types OWNER TO postgres;

--
-- Name: tbt_order_group_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_order_group_types (
    id character varying(21) NOT NULL,
    title character varying(5) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_order_group_types OWNER TO postgres;

--
-- Name: tbt_order_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_order_groups (
    id character varying(21) NOT NULL,
    user_id character varying(21) NOT NULL,
    affcode_id character varying(21) NOT NULL,
    customer_id character varying(21) NOT NULL,
    order_group_type_id character varying(21) NOT NULL,
    sub_order character varying(15) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_order_groups OWNER TO postgres;

--
-- Name: tbt_order_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_order_plans (
    id character varying(21) NOT NULL,
    download_id character varying(21) NOT NULL,
    order_zone_id character varying(21) NOT NULL,
    affcode_id character varying(21) NOT NULL,
    customer_id character varying(21) NOT NULL,
    revise_order_id character varying(21),
    ledger_id character varying(21) NOT NULL,
    pc_id character varying(21) NOT NULL,
    commercial_id character varying(21) NOT NULL,
    order_type_id character varying(21) NOT NULL,
    shipment_id character varying(21) NOT NULL,
    sample_flg_id character varying(21) NOT NULL,
    seq bigint,
    vendor character varying(5),
    cd character varying(5),
    tagrp character varying(5),
    sortg1 character varying(25),
    sortg2 character varying(25),
    sortg3 character varying(25),
    plan_type character varying(25),
    order_group character varying(25),
    pono character varying(25),
    rec_id character varying(25),
    biac character varying(25),
    etd_tap date,
    part_no character varying(25),
    part_name character varying(50),
    sample_flg character varying(2),
    orderorgi numeric,
    orderround numeric,
    firm_flg character varying(2),
    shipped_flg character varying(2),
    shipped_qty numeric,
    ordermonth date,
    bal_qty numeric,
    bidrfl character varying(2),
    delete_flg character varying(2),
    reasoncd character varying(5),
    upddte date,
    updtime timestamp with time zone,
    carrier_code character varying(5),
    bioabt bigint,
    bicomd character varying(2),
    bistdp numeric,
    binewt numeric,
    bigrwt numeric,
    bishpc character varying(25),
    biivpx character varying(5),
    bisafn character varying(25),
    biwidt numeric,
    bihigh numeric,
    bileng numeric,
    lot_no character varying(25),
    minimum bigint,
    maximum bigint,
    picshelfbin character varying(25),
    stkshelfbin character varying(25),
    ovsshelfbin character varying(25),
    picshelfbasic_qty numeric,
    outer_pcs numeric,
    allocate_qty numeric,
    description text,
    is_revise_error boolean,
    is_generate boolean,
    by_manually boolean,
    is_sync boolean,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_order_plans OWNER TO postgres;

--
-- Name: tbt_order_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_order_types (
    id character varying(21) NOT NULL,
    title character varying(5) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_order_types OWNER TO postgres;

--
-- Name: tbt_order_zones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_order_zones (
    id character varying(21) NOT NULL,
    value bigint NOT NULL,
    factory_id character varying(21) NOT NULL,
    whs_id character varying(21) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_order_zones OWNER TO postgres;

--
-- Name: tbt_parts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_parts (
    id character varying(21) NOT NULL,
    slug character varying(25),
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_parts OWNER TO postgres;

--
-- Name: tbt_pcs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_pcs (
    id character varying(21) NOT NULL,
    title character varying(5) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_pcs OWNER TO postgres;

--
-- Name: tbt_positions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_positions (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_positions OWNER TO postgres;

--
-- Name: tbt_receive_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_receive_details (
    id character varying(21) NOT NULL,
    receive_id character varying(21) NOT NULL,
    ledger_id character varying(21) NOT NULL,
    plan_qty bigint,
    plan_ctn bigint,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_receive_details OWNER TO postgres;

--
-- Name: tbt_receive_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_receive_types (
    id character varying(21) NOT NULL,
    whs_id character varying(21),
    prefix character varying(50) NOT NULL,
    title character varying(50) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_receive_types OWNER TO postgres;

--
-- Name: tbt_receives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_receives (
    id character varying(21) NOT NULL,
    download_id character varying(21) NOT NULL,
    receive_type_id character varying(21) NOT NULL,
    receive_date date,
    transfer_out_no character varying(15) NOT NULL,
    tex_no character varying(15),
    item bigint,
    plan_ctn bigint,
    receive_ctn bigint,
    is_sync boolean,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_receives OWNER TO postgres;

--
-- Name: tbt_revise_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_revise_orders (
    id character varying(21) NOT NULL,
    title character varying(5) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_revise_orders OWNER TO postgres;

--
-- Name: tbt_sample_flgs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_sample_flgs (
    id character varying(21) NOT NULL,
    title character varying(5) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_sample_flgs OWNER TO postgres;

--
-- Name: tbt_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_sections (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_sections OWNER TO postgres;

--
-- Name: tbt_shelves; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_shelves (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_print_location boolean,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_shelves OWNER TO postgres;

--
-- Name: tbt_shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_shipments (
    id character varying(21) NOT NULL,
    prefix character varying(10),
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_shipments OWNER TO postgres;

--
-- Name: tbt_sizes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_sizes (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_sizes OWNER TO postgres;

--
-- Name: tbt_system_loggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_system_loggers (
    id character varying(21) NOT NULL,
    user_id character varying(21),
    title character varying(25),
    description text,
    is_success boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_system_loggers OWNER TO postgres;

--
-- Name: tbt_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_units (
    id character varying(21) NOT NULL,
    title character varying(25) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_units OWNER TO postgres;

--
-- Name: tbt_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_users (
    id character varying(21) NOT NULL,
    username character varying(10) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(50) NOT NULL,
    password character varying(60) NOT NULL,
    area_id character varying(21),
    whs_id character varying(21),
    factory_id character varying(21),
    position_id character varying(21),
    section_id character varying(21),
    department_id character varying(21),
    avatar_url text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_users OWNER TO postgres;

--
-- Name: tbt_whs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbt_whs (
    id character varying(21) NOT NULL,
    prefix character varying(10) NOT NULL,
    title character varying(25) NOT NULL,
    value character varying(5),
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tbt_whs OWNER TO postgres;

--
-- Data for Name: tbt_administrators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_administrators (id, user_id, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_administrators (id, user_id, is_active, created_at, updated_at) FROM '$$PATH$$/3757.dat';

--
-- Data for Name: tbt_affcodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_affcodes (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_affcodes (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3766.dat';

--
-- Data for Name: tbt_areas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_areas (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_areas (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3753.dat';

--
-- Data for Name: tbt_carton_histories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_carton_histories (id, carton_id, pallet_no, shelve_id, qty, ip_address, emp_id, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_carton_histories (id, carton_id, pallet_no, shelve_id, qty, ip_address, emp_id, description, is_active, created_at, updated_at) FROM '$$PATH$$/3782.dat';

--
-- Data for Name: tbt_carton_not_receives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_carton_not_receives (id, receive_detail_id, transfer_out_no, part_no, lot_no, serial_no, qty, is_received, is_sync, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_carton_not_receives (id, receive_detail_id, transfer_out_no, part_no, lot_no, serial_no, qty, is_received, is_sync, created_at, updated_at) FROM '$$PATH$$/3780.dat';

--
-- Data for Name: tbt_cartons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_cartons (id, ledger_id, receive_detail_id, serial_no, lot_no, line_no, revise_no, pallet_no, shelve_id, qty, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_cartons (id, ledger_id, receive_detail_id, serial_no, lot_no, line_no, revise_no, pallet_no, shelve_id, qty, is_active, created_at, updated_at) FROM '$$PATH$$/3781.dat';

--
-- Data for Name: tbt_colors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_colors (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_colors (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3786.dat';

--
-- Data for Name: tbt_commercials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_commercials (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_commercials (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3770.dat';

--
-- Data for Name: tbt_customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_customers (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_customers (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3767.dat';

--
-- Data for Name: tbt_departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_departments (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_departments (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3752.dat';

--
-- Data for Name: tbt_download_mail_boxes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_download_mail_boxes (id, mail_box_id, mail_type_id, batch_no, size, batch_id, creation_date, flags, format, originator, file_path, is_download, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_download_mail_boxes (id, mail_box_id, mail_type_id, batch_no, size, batch_id, creation_date, flags, format, originator, file_path, is_download, is_active, created_at, updated_at) FROM '$$PATH$$/3784.dat';

--
-- Data for Name: tbt_factories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_factories (id, title, description, inv_prefix, label_prefix, value, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_factories (id, title, description, inv_prefix, label_prefix, value, is_active, created_at, updated_at) FROM '$$PATH$$/3763.dat';

--
-- Data for Name: tbt_item_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_item_types (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_item_types (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3760.dat';

--
-- Data for Name: tbt_jwt_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_jwt_tokens (id, user_id, token, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_jwt_tokens (id, user_id, token, is_active, created_at, updated_at) FROM '$$PATH$$/3756.dat';

--
-- Data for Name: tbt_kinds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_kinds (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_kinds (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3787.dat';

--
-- Data for Name: tbt_last_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_last_invoices (id, factory_id, affcode_id, on_year, last_running, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_last_invoices (id, factory_id, affcode_id, on_year, last_running, is_active, created_at, updated_at) FROM '$$PATH$$/3774.dat';

--
-- Data for Name: tbt_ledgers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_ledgers (id, area_id, whs_id, factory_id, part_id, kind_id, size_id, color_id, item_type_id, unit_id, dim_width, dim_length, dim_height, gross_weight, net_weight, qty, ctn, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_ledgers (id, area_id, whs_id, factory_id, part_id, kind_id, size_id, color_id, item_type_id, unit_id, dim_width, dim_length, dim_height, gross_weight, net_weight, qty, ctn, is_active, created_at, updated_at) FROM '$$PATH$$/3789.dat';

--
-- Data for Name: tbt_mail_boxes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_mail_boxes (id, area_id, mail_id, password, url, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_mail_boxes (id, area_id, mail_id, password, url, is_active, created_at, updated_at) FROM '$$PATH$$/3762.dat';

--
-- Data for Name: tbt_mail_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_mail_types (id, factory_id, prefix, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_mail_types (id, factory_id, prefix, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3764.dat';

--
-- Data for Name: tbt_order_group_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_order_group_types (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_order_group_types (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3775.dat';

--
-- Data for Name: tbt_order_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_order_groups (id, user_id, affcode_id, customer_id, order_group_type_id, sub_order, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_order_groups (id, user_id, affcode_id, customer_id, order_group_type_id, sub_order, description, is_active, created_at, updated_at) FROM '$$PATH$$/3776.dat';

--
-- Data for Name: tbt_order_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_order_plans (id, download_id, order_zone_id, affcode_id, customer_id, revise_order_id, ledger_id, pc_id, commercial_id, order_type_id, shipment_id, sample_flg_id, seq, vendor, cd, tagrp, sortg1, sortg2, sortg3, plan_type, order_group, pono, rec_id, biac, etd_tap, part_no, part_name, sample_flg, orderorgi, orderround, firm_flg, shipped_flg, shipped_qty, ordermonth, bal_qty, bidrfl, delete_flg, reasoncd, upddte, updtime, carrier_code, bioabt, bicomd, bistdp, binewt, bigrwt, bishpc, biivpx, bisafn, biwidt, bihigh, bileng, lot_no, minimum, maximum, picshelfbin, stkshelfbin, ovsshelfbin, picshelfbasic_qty, outer_pcs, allocate_qty, description, is_revise_error, is_generate, by_manually, is_sync, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_order_plans (id, download_id, order_zone_id, affcode_id, customer_id, revise_order_id, ledger_id, pc_id, commercial_id, order_type_id, shipment_id, sample_flg_id, seq, vendor, cd, tagrp, sortg1, sortg2, sortg3, plan_type, order_group, pono, rec_id, biac, etd_tap, part_no, part_name, sample_flg, orderorgi, orderround, firm_flg, shipped_flg, shipped_qty, ordermonth, bal_qty, bidrfl, delete_flg, reasoncd, upddte, updtime, carrier_code, bioabt, bicomd, bistdp, binewt, bigrwt, bishpc, biivpx, bisafn, biwidt, bihigh, bileng, lot_no, minimum, maximum, picshelfbin, stkshelfbin, ovsshelfbin, picshelfbasic_qty, outer_pcs, allocate_qty, description, is_revise_error, is_generate, by_manually, is_sync, is_active, created_at, updated_at) FROM '$$PATH$$/3777.dat';

--
-- Data for Name: tbt_order_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_order_types (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_order_types (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3772.dat';

--
-- Data for Name: tbt_order_zones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_order_zones (id, value, factory_id, whs_id, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_order_zones (id, value, factory_id, whs_id, description, is_active, created_at, updated_at) FROM '$$PATH$$/3773.dat';

--
-- Data for Name: tbt_parts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_parts (id, slug, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_parts (id, slug, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3785.dat';

--
-- Data for Name: tbt_pcs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_pcs (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_pcs (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3769.dat';

--
-- Data for Name: tbt_positions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_positions (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_positions (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3750.dat';

--
-- Data for Name: tbt_receive_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_receive_details (id, receive_id, ledger_id, plan_qty, plan_ctn, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_receive_details (id, receive_id, ledger_id, plan_qty, plan_ctn, is_active, created_at, updated_at) FROM '$$PATH$$/3779.dat';

--
-- Data for Name: tbt_receive_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_receive_types (id, whs_id, prefix, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_receive_types (id, whs_id, prefix, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3765.dat';

--
-- Data for Name: tbt_receives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_receives (id, download_id, receive_type_id, receive_date, transfer_out_no, tex_no, item, plan_ctn, receive_ctn, is_sync, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_receives (id, download_id, receive_type_id, receive_date, transfer_out_no, tex_no, item, plan_ctn, receive_ctn, is_sync, is_active, created_at, updated_at) FROM '$$PATH$$/3778.dat';

--
-- Data for Name: tbt_revise_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_revise_orders (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_revise_orders (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3768.dat';

--
-- Data for Name: tbt_sample_flgs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_sample_flgs (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_sample_flgs (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3771.dat';

--
-- Data for Name: tbt_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_sections (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_sections (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3751.dat';

--
-- Data for Name: tbt_shelves; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_shelves (id, title, description, is_print_location, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_shelves (id, title, description, is_print_location, is_active, created_at, updated_at) FROM '$$PATH$$/3783.dat';

--
-- Data for Name: tbt_shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_shipments (id, prefix, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_shipments (id, prefix, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3761.dat';

--
-- Data for Name: tbt_sizes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_sizes (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_sizes (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3788.dat';

--
-- Data for Name: tbt_system_loggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_system_loggers (id, user_id, title, description, is_success, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_system_loggers (id, user_id, title, description, is_success, created_at, updated_at) FROM '$$PATH$$/3759.dat';

--
-- Data for Name: tbt_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_units (id, title, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_units (id, title, description, is_active, created_at, updated_at) FROM '$$PATH$$/3758.dat';

--
-- Data for Name: tbt_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_users (id, username, first_name, last_name, email, password, area_id, whs_id, factory_id, position_id, section_id, department_id, avatar_url, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_users (id, username, first_name, last_name, email, password, area_id, whs_id, factory_id, position_id, section_id, department_id, avatar_url, is_active, created_at, updated_at) FROM '$$PATH$$/3755.dat';

--
-- Data for Name: tbt_whs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbt_whs (id, prefix, title, value, description, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.tbt_whs (id, prefix, title, value, description, is_active, created_at, updated_at) FROM '$$PATH$$/3754.dat';

--
-- Name: tbt_administrators tbt_administrators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_administrators
    ADD CONSTRAINT tbt_administrators_pkey PRIMARY KEY (id);


--
-- Name: tbt_administrators tbt_administrators_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_administrators
    ADD CONSTRAINT tbt_administrators_user_id_key UNIQUE (user_id);


--
-- Name: tbt_affcodes tbt_affcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_affcodes
    ADD CONSTRAINT tbt_affcodes_pkey PRIMARY KEY (id);


--
-- Name: tbt_affcodes tbt_affcodes_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_affcodes
    ADD CONSTRAINT tbt_affcodes_title_key UNIQUE (title);


--
-- Name: tbt_areas tbt_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_areas
    ADD CONSTRAINT tbt_areas_pkey PRIMARY KEY (id);


--
-- Name: tbt_areas tbt_areas_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_areas
    ADD CONSTRAINT tbt_areas_title_key UNIQUE (title);


--
-- Name: tbt_carton_histories tbt_carton_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_carton_histories
    ADD CONSTRAINT tbt_carton_histories_pkey PRIMARY KEY (id);


--
-- Name: tbt_carton_not_receives tbt_carton_not_receives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_carton_not_receives
    ADD CONSTRAINT tbt_carton_not_receives_pkey PRIMARY KEY (id);


--
-- Name: tbt_cartons tbt_cartons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_cartons
    ADD CONSTRAINT tbt_cartons_pkey PRIMARY KEY (id);


--
-- Name: tbt_cartons tbt_cartons_serial_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_cartons
    ADD CONSTRAINT tbt_cartons_serial_no_key UNIQUE (serial_no);


--
-- Name: tbt_colors tbt_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_colors
    ADD CONSTRAINT tbt_colors_pkey PRIMARY KEY (id);


--
-- Name: tbt_colors tbt_colors_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_colors
    ADD CONSTRAINT tbt_colors_title_key UNIQUE (title);


--
-- Name: tbt_commercials tbt_commercials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_commercials
    ADD CONSTRAINT tbt_commercials_pkey PRIMARY KEY (id);


--
-- Name: tbt_commercials tbt_commercials_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_commercials
    ADD CONSTRAINT tbt_commercials_title_key UNIQUE (title);


--
-- Name: tbt_customers tbt_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_customers
    ADD CONSTRAINT tbt_customers_pkey PRIMARY KEY (id);


--
-- Name: tbt_customers tbt_customers_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_customers
    ADD CONSTRAINT tbt_customers_title_key UNIQUE (title);


--
-- Name: tbt_departments tbt_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_departments
    ADD CONSTRAINT tbt_departments_pkey PRIMARY KEY (id);


--
-- Name: tbt_departments tbt_departments_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_departments
    ADD CONSTRAINT tbt_departments_title_key UNIQUE (title);


--
-- Name: tbt_download_mail_boxes tbt_download_mail_boxes_batch_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT tbt_download_mail_boxes_batch_no_key UNIQUE (batch_no);


--
-- Name: tbt_download_mail_boxes tbt_download_mail_boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT tbt_download_mail_boxes_pkey PRIMARY KEY (id);


--
-- Name: tbt_factories tbt_factories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_factories
    ADD CONSTRAINT tbt_factories_pkey PRIMARY KEY (id);


--
-- Name: tbt_factories tbt_factories_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_factories
    ADD CONSTRAINT tbt_factories_title_key UNIQUE (title);


--
-- Name: tbt_item_types tbt_item_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_item_types
    ADD CONSTRAINT tbt_item_types_pkey PRIMARY KEY (id);


--
-- Name: tbt_item_types tbt_item_types_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_item_types
    ADD CONSTRAINT tbt_item_types_title_key UNIQUE (title);


--
-- Name: tbt_jwt_tokens tbt_jwt_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT tbt_jwt_tokens_pkey PRIMARY KEY (id);


--
-- Name: tbt_jwt_tokens tbt_jwt_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT tbt_jwt_tokens_token_key UNIQUE (token);


--
-- Name: tbt_jwt_tokens tbt_jwt_tokens_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT tbt_jwt_tokens_user_id_key UNIQUE (user_id);


--
-- Name: tbt_kinds tbt_kinds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_kinds
    ADD CONSTRAINT tbt_kinds_pkey PRIMARY KEY (id);


--
-- Name: tbt_kinds tbt_kinds_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_kinds
    ADD CONSTRAINT tbt_kinds_title_key UNIQUE (title);


--
-- Name: tbt_last_invoices tbt_last_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_last_invoices
    ADD CONSTRAINT tbt_last_invoices_pkey PRIMARY KEY (id);


--
-- Name: tbt_ledgers tbt_ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT tbt_ledgers_pkey PRIMARY KEY (id);


--
-- Name: tbt_mail_boxes tbt_mail_boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_boxes
    ADD CONSTRAINT tbt_mail_boxes_pkey PRIMARY KEY (id);


--
-- Name: tbt_mail_types tbt_mail_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_types
    ADD CONSTRAINT tbt_mail_types_pkey PRIMARY KEY (id);


--
-- Name: tbt_mail_types tbt_mail_types_prefix_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_types
    ADD CONSTRAINT tbt_mail_types_prefix_key UNIQUE (prefix);


--
-- Name: tbt_order_group_types tbt_order_group_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_group_types
    ADD CONSTRAINT tbt_order_group_types_pkey PRIMARY KEY (id);


--
-- Name: tbt_order_group_types tbt_order_group_types_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_group_types
    ADD CONSTRAINT tbt_order_group_types_title_key UNIQUE (title);


--
-- Name: tbt_order_groups tbt_order_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_groups
    ADD CONSTRAINT tbt_order_groups_pkey PRIMARY KEY (id);


--
-- Name: tbt_order_plans tbt_order_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT tbt_order_plans_pkey PRIMARY KEY (id);


--
-- Name: tbt_order_types tbt_order_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_types
    ADD CONSTRAINT tbt_order_types_pkey PRIMARY KEY (id);


--
-- Name: tbt_order_types tbt_order_types_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_types
    ADD CONSTRAINT tbt_order_types_title_key UNIQUE (title);


--
-- Name: tbt_order_zones tbt_order_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_zones
    ADD CONSTRAINT tbt_order_zones_pkey PRIMARY KEY (id);


--
-- Name: tbt_parts tbt_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_parts
    ADD CONSTRAINT tbt_parts_pkey PRIMARY KEY (id);


--
-- Name: tbt_parts tbt_parts_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_parts
    ADD CONSTRAINT tbt_parts_slug_key UNIQUE (slug);


--
-- Name: tbt_parts tbt_parts_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_parts
    ADD CONSTRAINT tbt_parts_title_key UNIQUE (title);


--
-- Name: tbt_pcs tbt_pcs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_pcs
    ADD CONSTRAINT tbt_pcs_pkey PRIMARY KEY (id);


--
-- Name: tbt_pcs tbt_pcs_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_pcs
    ADD CONSTRAINT tbt_pcs_title_key UNIQUE (title);


--
-- Name: tbt_positions tbt_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_positions
    ADD CONSTRAINT tbt_positions_pkey PRIMARY KEY (id);


--
-- Name: tbt_positions tbt_positions_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_positions
    ADD CONSTRAINT tbt_positions_title_key UNIQUE (title);


--
-- Name: tbt_receive_details tbt_receive_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receive_details
    ADD CONSTRAINT tbt_receive_details_pkey PRIMARY KEY (id);


--
-- Name: tbt_receive_types tbt_receive_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receive_types
    ADD CONSTRAINT tbt_receive_types_pkey PRIMARY KEY (id);


--
-- Name: tbt_receive_types tbt_receive_types_prefix_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receive_types
    ADD CONSTRAINT tbt_receive_types_prefix_key UNIQUE (prefix);


--
-- Name: tbt_receives tbt_receives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receives
    ADD CONSTRAINT tbt_receives_pkey PRIMARY KEY (id);


--
-- Name: tbt_receives tbt_receives_transfer_out_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receives
    ADD CONSTRAINT tbt_receives_transfer_out_no_key UNIQUE (transfer_out_no);


--
-- Name: tbt_revise_orders tbt_revise_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_revise_orders
    ADD CONSTRAINT tbt_revise_orders_pkey PRIMARY KEY (id);


--
-- Name: tbt_revise_orders tbt_revise_orders_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_revise_orders
    ADD CONSTRAINT tbt_revise_orders_title_key UNIQUE (title);


--
-- Name: tbt_sample_flgs tbt_sample_flgs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sample_flgs
    ADD CONSTRAINT tbt_sample_flgs_pkey PRIMARY KEY (id);


--
-- Name: tbt_sample_flgs tbt_sample_flgs_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sample_flgs
    ADD CONSTRAINT tbt_sample_flgs_title_key UNIQUE (title);


--
-- Name: tbt_sections tbt_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sections
    ADD CONSTRAINT tbt_sections_pkey PRIMARY KEY (id);


--
-- Name: tbt_sections tbt_sections_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sections
    ADD CONSTRAINT tbt_sections_title_key UNIQUE (title);


--
-- Name: tbt_shelves tbt_shelves_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_shelves
    ADD CONSTRAINT tbt_shelves_pkey PRIMARY KEY (id);


--
-- Name: tbt_shelves tbt_shelves_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_shelves
    ADD CONSTRAINT tbt_shelves_title_key UNIQUE (title);


--
-- Name: tbt_shipments tbt_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_shipments
    ADD CONSTRAINT tbt_shipments_pkey PRIMARY KEY (id);


--
-- Name: tbt_shipments tbt_shipments_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_shipments
    ADD CONSTRAINT tbt_shipments_title_key UNIQUE (title);


--
-- Name: tbt_sizes tbt_sizes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sizes
    ADD CONSTRAINT tbt_sizes_pkey PRIMARY KEY (id);


--
-- Name: tbt_sizes tbt_sizes_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_sizes
    ADD CONSTRAINT tbt_sizes_title_key UNIQUE (title);


--
-- Name: tbt_system_loggers tbt_system_loggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_system_loggers
    ADD CONSTRAINT tbt_system_loggers_pkey PRIMARY KEY (id);


--
-- Name: tbt_units tbt_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_units
    ADD CONSTRAINT tbt_units_pkey PRIMARY KEY (id);


--
-- Name: tbt_units tbt_units_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_units
    ADD CONSTRAINT tbt_units_title_key UNIQUE (title);


--
-- Name: tbt_users tbt_users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT tbt_users_email_key UNIQUE (email);


--
-- Name: tbt_users tbt_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT tbt_users_pkey PRIMARY KEY (id);


--
-- Name: tbt_users tbt_users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT tbt_users_username_key UNIQUE (username);


--
-- Name: tbt_whs tbt_whs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_whs
    ADD CONSTRAINT tbt_whs_pkey PRIMARY KEY (id);


--
-- Name: tbt_whs tbt_whs_prefix_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_whs
    ADD CONSTRAINT tbt_whs_prefix_key UNIQUE (prefix);


--
-- Name: tbt_whs tbt_whs_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_whs
    ADD CONSTRAINT tbt_whs_title_key UNIQUE (title);


--
-- Name: idx_tbt_affcodes_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_affcodes_title ON public.tbt_affcodes USING btree (title);


--
-- Name: idx_tbt_areas_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_areas_title ON public.tbt_areas USING btree (title);


--
-- Name: idx_tbt_colors_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_colors_title ON public.tbt_colors USING btree (title);


--
-- Name: idx_tbt_commercials_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_commercials_title ON public.tbt_commercials USING btree (title);


--
-- Name: idx_tbt_customers_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_customers_title ON public.tbt_customers USING btree (title);


--
-- Name: idx_tbt_departments_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_departments_title ON public.tbt_departments USING btree (title);


--
-- Name: idx_tbt_factories_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_factories_title ON public.tbt_factories USING btree (title);


--
-- Name: idx_tbt_item_types_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_item_types_title ON public.tbt_item_types USING btree (title);


--
-- Name: idx_tbt_kinds_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_kinds_title ON public.tbt_kinds USING btree (title);


--
-- Name: idx_tbt_mail_types_prefix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_mail_types_prefix ON public.tbt_mail_types USING btree (prefix);


--
-- Name: idx_tbt_mail_types_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_mail_types_title ON public.tbt_mail_types USING btree (title);


--
-- Name: idx_tbt_order_group_types_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_order_group_types_title ON public.tbt_order_group_types USING btree (title);


--
-- Name: idx_tbt_order_types_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_order_types_title ON public.tbt_order_types USING btree (title);


--
-- Name: idx_tbt_parts_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_parts_title ON public.tbt_parts USING btree (title);


--
-- Name: idx_tbt_pcs_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_pcs_title ON public.tbt_pcs USING btree (title);


--
-- Name: idx_tbt_positions_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_positions_title ON public.tbt_positions USING btree (title);


--
-- Name: idx_tbt_receive_types_prefix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_receive_types_prefix ON public.tbt_receive_types USING btree (prefix);


--
-- Name: idx_tbt_receive_types_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_receive_types_title ON public.tbt_receive_types USING btree (title);


--
-- Name: idx_tbt_revise_orders_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_revise_orders_title ON public.tbt_revise_orders USING btree (title);


--
-- Name: idx_tbt_sample_flgs_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_sample_flgs_title ON public.tbt_sample_flgs USING btree (title);


--
-- Name: idx_tbt_sections_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_sections_title ON public.tbt_sections USING btree (title);


--
-- Name: idx_tbt_shelves_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_shelves_title ON public.tbt_shelves USING btree (title);


--
-- Name: idx_tbt_shipments_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_shipments_title ON public.tbt_shipments USING btree (title);


--
-- Name: idx_tbt_sizes_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_sizes_title ON public.tbt_sizes USING btree (title);


--
-- Name: idx_tbt_units_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_units_title ON public.tbt_units USING btree (title);


--
-- Name: idx_tbt_users_user_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_users_user_name ON public.tbt_users USING btree (username);


--
-- Name: idx_tbt_whs_prefix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_whs_prefix ON public.tbt_whs USING btree (prefix);


--
-- Name: idx_tbt_whs_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tbt_whs_title ON public.tbt_whs USING btree (title);


--
-- Name: tbt_administrators fk_tbt_administrators_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_administrators
    ADD CONSTRAINT fk_tbt_administrators_user FOREIGN KEY (user_id) REFERENCES public.tbt_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_cartons fk_tbt_cartons_ledger; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_cartons
    ADD CONSTRAINT fk_tbt_cartons_ledger FOREIGN KEY (ledger_id) REFERENCES public.tbt_ledgers(id);


--
-- Name: tbt_cartons fk_tbt_cartons_receive_detail; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_cartons
    ADD CONSTRAINT fk_tbt_cartons_receive_detail FOREIGN KEY (receive_detail_id) REFERENCES public.tbt_receive_details(id);


--
-- Name: tbt_cartons fk_tbt_cartons_shelve; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_cartons
    ADD CONSTRAINT fk_tbt_cartons_shelve FOREIGN KEY (shelve_id) REFERENCES public.tbt_shelves(id);


--
-- Name: tbt_download_mail_boxes fk_tbt_download_mail_boxes_mail_box; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT fk_tbt_download_mail_boxes_mail_box FOREIGN KEY (mail_box_id) REFERENCES public.tbt_mail_boxes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_download_mail_boxes fk_tbt_download_mail_boxes_mail_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_download_mail_boxes
    ADD CONSTRAINT fk_tbt_download_mail_boxes_mail_type FOREIGN KEY (mail_type_id) REFERENCES public.tbt_mail_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_jwt_tokens fk_tbt_jwt_tokens_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_jwt_tokens
    ADD CONSTRAINT fk_tbt_jwt_tokens_user FOREIGN KEY (user_id) REFERENCES public.tbt_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_last_invoices fk_tbt_last_invoices_affcode; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_last_invoices
    ADD CONSTRAINT fk_tbt_last_invoices_affcode FOREIGN KEY (affcode_id) REFERENCES public.tbt_affcodes(id);


--
-- Name: tbt_last_invoices fk_tbt_last_invoices_factory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_last_invoices
    ADD CONSTRAINT fk_tbt_last_invoices_factory FOREIGN KEY (factory_id) REFERENCES public.tbt_factories(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_area; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_area FOREIGN KEY (area_id) REFERENCES public.tbt_areas(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_color; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_color FOREIGN KEY (color_id) REFERENCES public.tbt_colors(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_factory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_factory FOREIGN KEY (factory_id) REFERENCES public.tbt_factories(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_item_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_item_type FOREIGN KEY (item_type_id) REFERENCES public.tbt_item_types(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_kind; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_kind FOREIGN KEY (kind_id) REFERENCES public.tbt_kinds(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_part; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_part FOREIGN KEY (part_id) REFERENCES public.tbt_parts(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_size; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_size FOREIGN KEY (size_id) REFERENCES public.tbt_sizes(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_unit; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_unit FOREIGN KEY (unit_id) REFERENCES public.tbt_units(id);


--
-- Name: tbt_ledgers fk_tbt_ledgers_whs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_ledgers
    ADD CONSTRAINT fk_tbt_ledgers_whs FOREIGN KEY (whs_id) REFERENCES public.tbt_whs(id);


--
-- Name: tbt_mail_boxes fk_tbt_mail_boxes_area; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_boxes
    ADD CONSTRAINT fk_tbt_mail_boxes_area FOREIGN KEY (area_id) REFERENCES public.tbt_areas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_mail_types fk_tbt_mail_types_factory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_mail_types
    ADD CONSTRAINT fk_tbt_mail_types_factory FOREIGN KEY (factory_id) REFERENCES public.tbt_factories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_order_groups fk_tbt_order_groups_affcode; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_groups
    ADD CONSTRAINT fk_tbt_order_groups_affcode FOREIGN KEY (affcode_id) REFERENCES public.tbt_affcodes(id);


--
-- Name: tbt_order_groups fk_tbt_order_groups_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_groups
    ADD CONSTRAINT fk_tbt_order_groups_customer FOREIGN KEY (customer_id) REFERENCES public.tbt_customers(id);


--
-- Name: tbt_order_groups fk_tbt_order_groups_order_group_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_groups
    ADD CONSTRAINT fk_tbt_order_groups_order_group_type FOREIGN KEY (order_group_type_id) REFERENCES public.tbt_order_group_types(id);


--
-- Name: tbt_order_groups fk_tbt_order_groups_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_groups
    ADD CONSTRAINT fk_tbt_order_groups_user FOREIGN KEY (user_id) REFERENCES public.tbt_users(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_affcode; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_affcode FOREIGN KEY (affcode_id) REFERENCES public.tbt_affcodes(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_commercial; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_commercial FOREIGN KEY (commercial_id) REFERENCES public.tbt_commercials(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_customer FOREIGN KEY (customer_id) REFERENCES public.tbt_customers(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_download_mail_box; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_download_mail_box FOREIGN KEY (download_id) REFERENCES public.tbt_download_mail_boxes(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_ledger; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_ledger FOREIGN KEY (ledger_id) REFERENCES public.tbt_ledgers(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_order_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_order_type FOREIGN KEY (order_type_id) REFERENCES public.tbt_order_types(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_order_zone; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_order_zone FOREIGN KEY (order_zone_id) REFERENCES public.tbt_order_zones(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_pc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_pc FOREIGN KEY (pc_id) REFERENCES public.tbt_pcs(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_revise_order; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_revise_order FOREIGN KEY (revise_order_id) REFERENCES public.tbt_revise_orders(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_sample_flg; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_sample_flg FOREIGN KEY (sample_flg_id) REFERENCES public.tbt_sample_flgs(id);


--
-- Name: tbt_order_plans fk_tbt_order_plans_shipment; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_plans
    ADD CONSTRAINT fk_tbt_order_plans_shipment FOREIGN KEY (shipment_id) REFERENCES public.tbt_shipments(id);


--
-- Name: tbt_order_zones fk_tbt_order_zones_factory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_zones
    ADD CONSTRAINT fk_tbt_order_zones_factory FOREIGN KEY (factory_id) REFERENCES public.tbt_factories(id);


--
-- Name: tbt_order_zones fk_tbt_order_zones_whs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_order_zones
    ADD CONSTRAINT fk_tbt_order_zones_whs FOREIGN KEY (whs_id) REFERENCES public.tbt_whs(id);


--
-- Name: tbt_carton_not_receives fk_tbt_receive_details_carton_not_receive; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_carton_not_receives
    ADD CONSTRAINT fk_tbt_receive_details_carton_not_receive FOREIGN KEY (receive_detail_id) REFERENCES public.tbt_receive_details(id);


--
-- Name: tbt_receive_details fk_tbt_receive_details_ledger; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receive_details
    ADD CONSTRAINT fk_tbt_receive_details_ledger FOREIGN KEY (ledger_id) REFERENCES public.tbt_ledgers(id);


--
-- Name: tbt_receive_types fk_tbt_receive_types_whs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receive_types
    ADD CONSTRAINT fk_tbt_receive_types_whs FOREIGN KEY (whs_id) REFERENCES public.tbt_whs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_receives fk_tbt_receives_download_mail_box; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receives
    ADD CONSTRAINT fk_tbt_receives_download_mail_box FOREIGN KEY (download_id) REFERENCES public.tbt_download_mail_boxes(id);


--
-- Name: tbt_receive_details fk_tbt_receives_receive_detail; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receive_details
    ADD CONSTRAINT fk_tbt_receives_receive_detail FOREIGN KEY (receive_id) REFERENCES public.tbt_receives(id);


--
-- Name: tbt_receives fk_tbt_receives_receive_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_receives
    ADD CONSTRAINT fk_tbt_receives_receive_type FOREIGN KEY (receive_type_id) REFERENCES public.tbt_receive_types(id);


--
-- Name: tbt_system_loggers fk_tbt_system_loggers_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_system_loggers
    ADD CONSTRAINT fk_tbt_system_loggers_user FOREIGN KEY (user_id) REFERENCES public.tbt_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_area; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_area FOREIGN KEY (area_id) REFERENCES public.tbt_areas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_department FOREIGN KEY (department_id) REFERENCES public.tbt_departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_factory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_factory FOREIGN KEY (factory_id) REFERENCES public.tbt_factories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_position; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_position FOREIGN KEY (position_id) REFERENCES public.tbt_positions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_section; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_section FOREIGN KEY (section_id) REFERENCES public.tbt_sections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbt_users fk_tbt_users_whs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbt_users
    ADD CONSTRAINT fk_tbt_users_whs FOREIGN KEY (whs_id) REFERENCES public.tbt_whs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

